#include <iostream>
#include <fstream>
#include <string>
#include <queue>
#include <stack>
#include <unordered_map>

using namespace std;

struct Libro {
    string titulo;
    string autor;
    int anoEdicion;
    string editorial;
    string isbn;
    int paginas;
    bool disponible;
    Libro* siguiente;
};

struct Lector {
    string nombre;
    int dni;
    string libroSolicitado;
    Lector* siguiente;
};

Libro* listaLibros = nullptr;
queue<Lector*> colaSolicitudes;
stack<string> historial;
unordered_map<string, string> librosSolicitados;

void agregarLibro(Libro*& lista, const string& titulo, const string& autor, int ano, const string& editorial, const string& isbn, int paginas, bool disponible);
void cargarLibros(Libro*& lista);
void guardarLibros(Libro* lista);
void ordenarLibrosPorTitulo(Libro*& lista);
void mostrarHistorial();
void vaciarBiblioteca(Libro*& lista);
Libro* buscarLibroPorTitulo(Libro* lista, const string& titulo);
void solicitarLibro(queue<Lector*>& cola, const string& nombre, int dni, const string& libroSolicitado);
void devolverLibro(queue<Lector*>& cola, const string& libroDevuelto);
void guardarSolicitud(Lector* lector);

void agregarLibro(Libro*& lista, const string& titulo, const string& autor, int ano, const string& editorial, const string& isbn, int paginas, bool disponible) {
    Libro* nuevoLibro = new Libro{titulo, autor, ano, editorial, isbn, paginas, disponible, nullptr};
    if (!lista) {
        lista = nuevoLibro;
    } else {
        Libro* actual = lista;
        while (actual->siguiente) {
            actual = actual->siguiente;
        }
        actual->siguiente = nuevoLibro;
    }
    historial.push("Libro agregado: " + titulo);
}

void cargarLibros(Libro*& lista) {
    ifstream archivo("biblioteca.txt");
    if (archivo.is_open()) {
        string titulo, autor, editorial, isbn;
        int ano, paginas;
        while (getline(archivo, titulo, ',') &&
               getline(archivo, autor, ',') &&
               archivo >> ano &&
               archivo.ignore() &&
               getline(archivo, editorial, ',') &&
               getline(archivo, isbn, ',') &&
               archivo >> paginas &&
               archivo.ignore()) {
            agregarLibro(lista, titulo, autor, ano, editorial, isbn, paginas, true);
        }
        archivo.close();
        historial.push("Datos de libros cargados");
    } else {
        cout << "No se pudo abrir el archivo para cargar." << endl;
    }
}

void guardarLibros(Libro* lista) {
    ofstream archivo("biblioteca.txt");
    if (archivo.is_open()) {
        for (Libro* actual = lista; actual != nullptr; actual = actual->siguiente) {
            if (actual->disponible) {
                archivo << actual->titulo << "," << actual->autor << "," << actual->anoEdicion << ","
                        << actual->editorial << "," << actual->isbn << "," << actual->paginas << endl;
            }
        }
        archivo.close();
    } else {
        cout << "No se pudo abrir el archivo para guardar." << endl;
    }
}

void ordenarLibrosPorTitulo(Libro*& lista) {
    if (!lista || !lista->siguiente) {
        return; // No hay necesidad de ordenar si la lista está vacía o tiene un solo elemento
    }

    bool ordenado;
    do {
        ordenado = true;
        Libro* actual = lista;
        Libro* anterior = nullptr;
        Libro* siguiente = lista->siguiente;

        while (siguiente) {
            // Comparar títulos de libros consecutivos
            if (actual->titulo > siguiente->titulo) {
                ordenado = false;

                // Intercambiar nodos en la lista enlazada
                if (anterior) {
                    anterior->siguiente = siguiente;
                } else {
                    lista = siguiente; // Cambiar la cabeza de la lista si necesario
                }

                actual->siguiente = siguiente->siguiente;
                siguiente->siguiente = actual;

                // Ajustar punteros
                anterior = siguiente;
                siguiente = actual->siguiente;
            } else {
                // Avanzar al siguiente par de nodos
                anterior = actual;
                actual = siguiente;
                siguiente = siguiente->siguiente;
            }
        }
    } while (!ordenado);

    historial.push("Libros ordenados por titulo");
}

void mostrarHistorial() {
    cout << "Historial de operaciones:\n";
    stack<string> aux = historial;
    while (!aux.empty()) {
        cout << aux.top() << endl;
        aux.pop();
    }
}

void vaciarBiblioteca(Libro*& lista) {
    while (lista) {
        Libro* temp = lista;
        lista = lista->siguiente;
        delete temp;
    }
    ofstream archivo("biblioteca.txt", ios::trunc);
    archivo.close();
    historial.push("Biblioteca vaciada");
    cout << "La biblioteca ha sido vaciada." << endl;
}

void vaciarSolicitudes() {
    ofstream archivo("solicitudes.txt", ios::trunc);
    if (archivo.is_open()) {
        cout << "El archivo de solicitudes ha sido vaciado." << endl;
        archivo.close();
    } else {
        cout << "No se pudo abrir el archivo para vaciar." << endl;
    }
}

Libro* buscarLibroPorTitulo(Libro* lista, const string& titulo) {
    Libro* actual = lista;
    while (actual) {
        if (actual->titulo == titulo) {
            return actual;
        }
        actual = actual->siguiente;
    }
    return nullptr;
}

void solicitarLibro(queue<Lector*>& cola, const string& nombre, int dni, const string& libroSolicitado) {
    Libro* libro = buscarLibroPorTitulo(listaLibros, libroSolicitado);
    if (!libro || !libro->disponible) {
        cout << "No encontramos el libro que solicitaste o ya esta solicitado." << endl;
        return;
    }
    libro->disponible = false;
    Lector* nuevoLector = new Lector{nombre, dni, libroSolicitado, nullptr};
    cola.push(nuevoLector);
    historial.push("Solicitud libro: " + nombre + " para " + libroSolicitado);
    guardarSolicitud(nuevoLector);
    guardarLibros(listaLibros);
}

void devolverLibro(queue<Lector*>& cola, const string& libroDevuelto) {
    // Buscamos el libro en la lista
    Libro* libro = buscarLibroPorTitulo(listaLibros, libroDevuelto);

    // Verificamos si el libro existe y está actualmente prestado
    if (libro && !libro->disponible) {
        libro->disponible = true;
        cout << "Libro '" << libroDevuelto << "' ha sido devuelto y esta disponible para ser solicitado nuevamente." << endl;

        // Verificamos si el primer lector en la cola solicitó este libro
        if (!cola.empty() && cola.front()->libroSolicitado == libroDevuelto) {
            // Notificamos al lector y lo eliminamos de la cola
            Lector* lector = cola.front();
            cout << "El lector " << lector->nombre << " ha sido notificado para que retire el libro." << endl;
            delete lector; // Liberamos la memoria del lector atendido
            cola.pop();    // Removemos al lector de la cola
        }

        // Guardamos el estado actualizado de los libros
        guardarLibros(listaLibros);
    } else {
        cout << "Este libro no estaba marcado como solicitado o ya fue devuelto." << endl;
    }
}


void guardarSolicitud(Lector* lector) {
    ofstream archivo("solicitudes.txt", ios::app);
    if (archivo.is_open()) {
        archivo << lector->nombre << "," << lector->dni << "," << lector->libroSolicitado << "\n";
        archivo.close();
    } else {
        cout << "No se pudo abrir el archivo para guardar solicitudes." << endl;
    }
}


int main() {
    int opcion;
    cargarLibros(listaLibros);

    do {
        cout << "\nSistema de Gestion de Biblioteca\n";
        cout << "1. Agregar libro\n";
        cout << "2. Ordenar libros por titulo\n";
        cout << "3. Buscar libro por titulo\n";
        cout << "4. Solicitar libro\n";
        cout << "5. Devolver libro\n";
        cout << "6. Guardar y salir\n";
        cout << "7. Ver historial de operaciones\n";
        cout << "8. Vaciar biblioteca\n";
        cout << "9. Vaciar archivo de solicitudes\n";
        cout << "0. Salir\n";
        cout << "Opcion: ";
        cin >> opcion;
        cin.ignore();

        switch (opcion) {
            case 1: {
                string titulo, autor, editorial, isbn;
                int ano, paginas;
                cout << "Titulo: "; getline(cin, titulo);
                cout << "Autor: "; getline(cin, autor);

                // Validación para el año de edición
                while (true) {
                    cout << "Ano de edicion: ";
                    if (!(cin >> ano)) {
                        cin.clear();
                        cin.ignore(1000, '\n');
                        cout << "Ingrese un numero para el ano de edicion.\n";
                    } else {
                        cin.ignore();
                        break;
                    }
                }

                cout << "Editorial: "; getline(cin, editorial);
                cout << "ISBN: "; getline(cin, isbn);

                // Validación para la cantidad de páginas
                while (true) {
                    cout << "Paginas: ";
                    if (!(cin >> paginas)) { // Verifica si la entrada no es un número
                        cin.clear(); // Limpia el estado de error de cin
                        cin.ignore(1000, '\n'); // Ignora hasta 1000 caracteres o hasta el próximo '\n'
                        cout << "Ingrese un numero para la cantidad de paginas.\n";
                    } else {
                        cin.ignore();
                        break;
                    }
                }

                agregarLibro(listaLibros, titulo, autor, ano, editorial, isbn, paginas, true);
                guardarLibros(listaLibros);
                break;
            }
            case 2:
                ordenarLibrosPorTitulo(listaLibros);
                guardarLibros(listaLibros); // Guarda la lista ordenada en el archivo
                cout << "Libros ordenados por titulo y guardados en biblioteca.txt.\n";
                break;
            case 3: {
                string titulo;
                cout << "Ingrese el titulo del libro a buscar: "; getline(cin, titulo);
                Libro* encontrado = buscarLibroPorTitulo(listaLibros, titulo);
                if (encontrado) {
                    cout << "Libro encontrado: " << encontrado->titulo << " de " << encontrado->autor << endl;
                } else {
                    cout << "No se encontro el libro o no esta disponible.\n";
                }
                break;
            }
            case 4: {
                string nombre, titulo;
                int dni;
                cout << "Nombre del lector: "; getline(cin, nombre);
                cout << "DNI del lector: "; cin >> dni; cin.ignore();
                cout << "Libro solicitado: "; getline(cin, titulo);
                solicitarLibro(colaSolicitudes, nombre, dni, titulo);
                break;
            }
            case 5: {
                string libroDevuelto;
                cout << "Libro devuelto: "; getline(cin, libroDevuelto);
                devolverLibro(colaSolicitudes, libroDevuelto);
                break;
            }
            case 6:
                guardarLibros(listaLibros);
                cout << "Datos guardados. Saliendo...\n";
                break;
            case 7:
                mostrarHistorial();
                break;
            case 8:
                vaciarBiblioteca(listaLibros);
                break;
            case 9:
                vaciarSolicitudes();
                break;
            case 0:
                cout << "Saliendo...\n";
                break;
            default:
                cout << "Opcion no valida.\n";
        }
    } while (opcion != 0);

    return 0;
}
