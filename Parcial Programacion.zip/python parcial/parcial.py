import csv
from collections import deque

# Clase que representa un libro en la biblioteca
class Libro:
    def __init__(self, titulo, autor, ano_edicion, editorial, isbn, paginas, disponible=True):
        self.titulo = titulo
        self.autor = autor
        self.ano_edicion = ano_edicion
        self.editorial = editorial
        self.isbn = isbn
        self.paginas = paginas
        self.disponible = disponible

# Clase que representa un lector que solicita un libro
class Lector:
    def __init__(self, nombre, dni, libro_solicitado):
        self.nombre = nombre
        self.dni = dni
        self.libro_solicitado = libro_solicitado

# Variables globales
lista_libros = []  # Lista de libros en la biblioteca
cola_solicitudes = deque()  # Cola para solicitudes de prestamo
registro_historial = []  # Historial de operaciones

# Agregar un nuevo libro a la biblioteca
def anadir_libro(titulo, autor, ano, editorial, isbn, paginas):
    nuevo_libro = Libro(titulo, autor, ano, editorial, isbn, paginas)
    lista_libros.append(nuevo_libro)
    registro_historial.append(f"Libro anadido: {titulo}")
    guardar_datos_libros()

# Cargar los datos de los libros desde el archivo CSV
def cargar_datos_libros():
    try:
        with open("biblioteca.csv", newline='', encoding="utf-8") as archivo:
            lector_csv = csv.reader(archivo)
            for fila in lector_csv:
                titulo, autor, ano, editorial, isbn, paginas = fila
                anadir_libro(titulo, autor, int(ano), editorial, isbn, int(paginas))
        print("Libros cargados correctamente.")
    except FileNotFoundError:
        print("Archivo de libros no encontrado para cargar.")

# Guardar los datos de los libros en el archivo CSV
def guardar_datos_libros():
    with open("biblioteca.csv", mode="w", newline='', encoding="utf-8") as archivo:
        escritor_csv = csv.writer(archivo)
        for libro in lista_libros:
            if libro.disponible:
                escritor_csv.writerow([libro.titulo, libro.autor, libro.ano_edicion, 
                                       libro.editorial, libro.isbn, libro.paginas])

# Guardar una nueva solicitud en el archivo solicitudes.txt (crea el archivo si no existe)
def guardar_solicitud(nombre, dni, titulo_libro):
    with open("solicitudes.txt", mode="a", encoding="utf-8") as archivo:
        archivo.write(f"{nombre}, {dni}, {titulo_libro}\n")

# Ordenar los libros por titulo
def ordenar_libros_titulo():
    lista_libros.sort(key=lambda libro: libro.titulo)
    registro_historial.append("Libros ordenados por titulo")
    guardar_datos_libros()
    print("Libros ordenados y guardados en biblioteca.csv.")

# Mostrar el historial de operaciones realizadas
def ver_historial_operaciones():
    print("Historial de operaciones:")
    for operacion in registro_historial:
        print(operacion)

# Buscar un libro por su titulo en la biblioteca
def localizar_libro_titulo(titulo):
    for libro in lista_libros:
        if libro.titulo == titulo:
            return libro
    return None

# Realizar una solicitud de prestamo de un libro
def solicitar_libro_prestamo(nombre, dni, titulo_libro):
    libro = localizar_libro_titulo(titulo_libro)
    if not libro or not libro.disponible:
        print("El libro no se encuentra o ya ha sido solicitado.")
        return

    libro.disponible = False
    nuevo_lector = Lector(nombre, dni, titulo_libro)
    cola_solicitudes.append(nuevo_lector)
    registro_historial.append(f"Solicitud de prestamo: {nombre} para {titulo_libro}")
    guardar_datos_libros()
    guardar_solicitud(nombre, dni, titulo_libro)  # Guardar la nueva solicitud en el archivo solicitudes.txt

# Devolver un libro a la biblioteca y actualizar su disponibilidad
def devolver_libro_biblioteca(titulo_libro):
    libro = localizar_libro_titulo(titulo_libro)
    if libro and not libro.disponible:
        libro.disponible = True
        print(f"Libro '{titulo_libro}' devuelto y disponible.")
        guardar_datos_libros()
    else:
        print("El libro ya estaba disponible o no se ha encontrado en la biblioteca.")

# Vaciar completamente la lista de libros y el archivo correspondiente
def limpiar_biblioteca():
    lista_libros.clear()
    with open("biblioteca.csv", "w", encoding="utf-8") as archivo:
        pass
    registro_historial.append("Biblioteca vaciada")
    print("La biblioteca ha sido vaciada.")

# Vaciar la cola de solicitudes y el archivo correspondiente
def limpiar_archivo_solicitudes():
    cola_solicitudes.clear()
    with open("solicitudes.txt", "w", encoding="utf-8") as archivo:
        pass
    print("Archivo de solicitudes vaciado.")

# Menu principal del sistema de gestion de biblioteca
def menu_principal():
    cargar_datos_libros()

    while True:
        print("\nSistema de Gestion de Biblioteca")
        print("1. Anadir libro")
        print("2. Ordenar libros por titulo")
        print("3. Buscar libro por titulo")
        print("4. Solicitar libro")
        print("5. Devolver libro")
        print("6. Guardar y salir")
        print("7. Ver historial de operaciones")
        print("8. Limpiar biblioteca")
        print("9. Limpiar archivo de solicitudes")
        print("0. Salir")
        opcion = input("Opcion: ")

        if opcion == "1":
            titulo = input("Titulo: ")
            autor = input("Autor: ")

            while True:
                try:
                    ano = int(input("Ano de edicion: "))
                    break
                except ValueError:
                    print("Ingrese un numero para el ano de edicion.")

            editorial = input("Editorial: ")
            isbn = input("ISBN: ")

            while True:
                try:
                    paginas = int(input("Paginas: "))
                    break
                except ValueError:
                    print("Ingrese un numero para la cantidad de paginas.")

            anadir_libro(titulo, autor, ano, editorial, isbn, paginas)

        elif opcion == "2":
            ordenar_libros_titulo()

        elif opcion == "3":
            titulo = input("Ingrese el titulo del libro a buscar: ")
            libro = localizar_libro_titulo(titulo)
            if libro:
                print(f"Libro encontrado: {libro.titulo} de {libro.autor}")
            else:
                print("No se encontro el libro o no esta disponible.")

        elif opcion == "4":
            nombre = input("Nombre del lector: ")
            dni = input("DNI del lector: ")
            titulo_libro = input("Libro solicitado: ")
            solicitar_libro_prestamo(nombre, dni, titulo_libro)

        elif opcion == "5":
            titulo_libro = input("Libro devuelto: ")
            devolver_libro_biblioteca(titulo_libro)

        elif opcion == "6":
            guardar_datos_libros()
            print("Datos guardados. Saliendo...")
            break

        elif opcion == "7":
            ver_historial_operaciones()

        elif opcion == "8":
            limpiar_biblioteca()

        elif opcion == "9":
            limpiar_archivo_solicitudes()

        elif opcion == "0":
            print("Saliendo...")
            break

        else:
            print("Opcion no valida.")

if __name__ == "__main__":
    menu_principal()
